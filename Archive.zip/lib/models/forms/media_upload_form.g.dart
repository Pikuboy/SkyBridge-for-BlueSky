// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'media_upload_form.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

MediaUploadForm _$MediaUploadFormFromJson(Map<String, dynamic> json) =>
    MediaUploadForm(
      description: json['description'] as String?,
      focus: json['focus'] as String?,
    );

Map<String, dynamic> _$MediaUploadFormToJson(MediaUploadForm instance) =>
    <String, dynamic>{
      'description': instance.description,
      'focus': instance.focus,
    };
