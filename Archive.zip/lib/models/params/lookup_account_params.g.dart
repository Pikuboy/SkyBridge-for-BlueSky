// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'lookup_account_params.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

LookupAccountParams _$LookupAccountParamsFromJson(Map<String, dynamic> json) =>
    LookupAccountParams(
      acct: json['acct'] as String,
    );

Map<String, dynamic> _$LookupAccountParamsToJson(
        LookupAccountParams instance) =>
    <String, dynamic>{
      'acct': instance.acct,
    };
