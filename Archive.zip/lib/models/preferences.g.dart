// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'preferences.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

SkybridgePreferences _$SkybridgePreferencesFromJson(
        Map<String, dynamic> json) =>
    SkybridgePreferences(
      showRepliesInHome: json['showRepliesInHome'] as bool? ?? false,
    );

Map<String, dynamic> _$SkybridgePreferencesToJson(
        SkybridgePreferences instance) =>
    <String, dynamic>{
      'showRepliesInHome': instance.showRepliesInHome,
    };
