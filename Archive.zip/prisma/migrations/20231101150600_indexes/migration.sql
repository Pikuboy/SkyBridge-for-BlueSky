-- CreateIndex
CREATE INDEX "PostRecord_cid_idx" ON "PostRecord"("cid");

-- CreateIndex
CREATE INDEX "UserRecord_did_idx" ON "UserRecord"("did");
