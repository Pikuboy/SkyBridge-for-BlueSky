import 'package:dart_frog/dart_frog.dart';
import 'package:sky_bridge/auth.dart';
import 'package:sky_bridge/database.dart';
import 'package:sky_bridge/models/mastodon/mastodon_post.dart';
import 'package:sky_bridge/models/params/timeline_params.dart';
import 'package:sky_bridge/util.dart';

Future<Response> onRequest(RequestContext context) async {
  final params = context.request.uri.queryParameters;
  final encodedParams = TimelineParams.fromJson(params);

  // Get a bluesky connection/session from the a provided bearer token.
  // If the token is invalid, bail out and return an error.
  final bluesky = await blueskyFromContext(context);
  if (bluesky == null) return authError();

  final List<MastodonPost> allPosts;
  String? nextCursor;

  // Check if we should allow posts to be backfilled.
  final backfillAllowed = env
      .getOrElse(
        'SKYBRIDGE_ALLOW_BACKFILL',
        () => 'false',
      )
      .toLowerCase();

  if (encodedParams.isNewPostsRequest && backfillAllowed == 'true') {
    // Get all the posts following minId so that Ivory can backfill its timeline
    allPosts = [];

    final lastRead = BigInt.parse(encodedParams.minId!);
    BigInt? maxID;
    String? prevCursor;
    var done = false;

    while (!done) {
      final feed = await bluesky.feed.getTimeline(
        limit: 100,
        cursor: prevCursor,
      );

      final posts = await databaseTransaction(() async {
        final futures = feed.data.feed.map<Future<MastodonPost>>(MastodonPost.fromFeedView).toList();
        return Future.wait(futures);
      });

      for (final post in posts) {
        final id = BigInt.parse(post.id);
        if (id <= lastRead) {
          // We've seen the last-read post (or something older than that).
          // That means we're fully caught up with the supplied min_id
          done = true;
          break;
        }

        if (maxID == null || id < maxID) {
          maxID = id - BigInt.one;
        }

        allPosts.add(post);
      }

      print(
        'Loaded ${posts.length} posts (total ${allPosts.length}, new maxID=$maxID)',
      );
      prevCursor = feed.data.cursor;

      if (posts.length < 25 || allPosts.length > 400) {
        // Bail early and don't try to fetch more posts if the batch was tiny
        done = true;
      }
    }

    nextCursor = prevCursor;
  } else {
    // Make a single, standard request
    // Support both max_id and cursor for pagination
    final paginationCursor = encodedParams.cursor ?? encodedParams.maxId;
    
    final feed = await bluesky.feed.getTimeline(
      limit: encodedParams.limit,
      cursor: paginationCursor,
    );

    allPosts = await databaseTransaction(() async {
      final futures = feed.data.feed.map<Future<MastodonPost>>(MastodonPost.fromFeedView).toList();
      return Future.wait(futures);
    });
    nextCursor = feed.data.cursor;
  }

  // Get the parent posts for each post.
  final processedPosts = await processParentPosts(bluesky, allPosts);

  var headers = <String, String>{};
  if (processedPosts.isNotEmpty) {
    headers = generatePaginationHeaders(
      items: processedPosts,
      requestUri: context.request.uri,
      nextCursor: nextCursor ?? '',
      getId: (post) => BigInt.parse(post.id),
    );
  }

  // If the user prefers not to see replies, we need to filter them out.
  final preferences = preferencesFromContext(context);
  if (!preferences.showRepliesInHome) {
    processedPosts.removeWhere((post) => post.inReplyToId != null);
  }

  return threadedJsonResponse(body: processedPosts, headers: headers);
}
